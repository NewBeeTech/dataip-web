module.exports = {
  'POST /api/ispace/UserParamset/append': {
        "result": "0",
        "data": "向自定义参数组追加参数成功"
    },
  'POST /api/ispace/UserParamset/update': {
        "result": "0",
        "data": "更新参数组成功"
    },
  'POST /api/ispace/UserParamset/new': {
        "result": "0",
        "data": "添加参数组成功"
    }
};
