/**
 * Created by wyz on 2017/12/28.
 */
// 数据浏览 page   chart 图表查看页面

const ViewChartData = ({  }) => {
  return (
    <div>这里是数据查看页面</div>
  )
}

export default ViewChartData
