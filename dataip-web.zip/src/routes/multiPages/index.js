import React from 'react';
import PropTypes from 'prop-types';

const Multiple = ({}) => {
    const handleClick = () => {};
    return (
        <div onClick={handleClick}>
        test
        </div>
    );
}

Multiple.propTypes = {
    // : PropTypes.
};

export default Multiple;
